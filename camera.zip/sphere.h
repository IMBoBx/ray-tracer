#ifndef SPHERE_H
#define SPHERE_H

#include "hittable.h"
#include "ray_tracer.h"

class sphere : public hittable {
   private:
    point3 center;
    double radius;
    shared_ptr<material> mat;

   public:
    sphere(const point3& center, double radius, shared_ptr<material> mat)
        : center(center), radius(std::fmax(0, radius)), mat(mat) {}

    bool hit(const ray& r, interval ray_t, hit_record& rec) const override {
        vec3 oc = center - r.origin();
        vec3 dir = r.direction();

        double a = dir.length_squared();
        // b = -2*dir - oc; use b = -2h;
        double h = dot(dir, oc);
        double c = oc.length_squared() - radius * radius;

        double discriminant = h * h - a * c;  //

        if (discriminant < 0) {
            return false;
        }

        double sqrtd = std::sqrt(discriminant);

        // finding nearest root
        double root = (h - sqrtd) / a;
        if (!ray_t.surrounds(root)) {
            root = (h + sqrtd) / a;
            if (!ray_t.surrounds(root)) {
                return false;
            }
        }

        rec.t = root;
        rec.p = r.at(root);
        vec3 outward_normal = (rec.p - center) / radius;
        rec.set_face_normal(r, outward_normal);
        rec.mat = mat;

        return true;
    }
};

#endif